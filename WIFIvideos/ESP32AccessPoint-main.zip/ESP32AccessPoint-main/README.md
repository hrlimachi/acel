# ESP32: Access point and connect to router examples
Simple example to setup ESP32 as an Access Point or to connect ESP32 to a router
